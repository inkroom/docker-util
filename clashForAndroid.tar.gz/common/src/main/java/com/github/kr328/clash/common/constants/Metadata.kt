package com.github.kr328.clash.common.constants

import com.github.kr328.clash.common.util.packageName

object Metadata {
    val GEOIP_FILE_NAME = "$packageName.GEOIP_FILE_NAME"
}