package com.github.kr328.clash.design.model

enum class DarkMode {
    Auto, ForceLight, ForceDark
}
