package observable

type Iterable <-chan any
